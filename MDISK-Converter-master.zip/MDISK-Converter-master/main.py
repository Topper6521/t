from bot import Bot

if __name__ == '__main__':
    print("Bot started")
    Bot.bot.run()
