ADMINS = list(int(i.strip()) for i in "2132021818".split(","))

print(ADMINS)