# URL Shortener Bot V2

<p align="center">
  <a href="https://github.com/kevinnadar22/URL-Shortener-V2/stargazers">
    <img src="https://img.shields.io/github/stars/kevinnadar22/URL-Shortener-V2?style=social">

  </a>
  
  <a href="https://github.com/kevinnadar22/URL-Shortener-V2/fork">
    <img src="https://img.shields.io/github/forks/kevinnadar22/URL-Shortener-V2?label=Fork&style=social">

  </a>  
</p>

__Just Send Any Link To Short. It Will Short To Save it to your MDisk Account__


## Usage

**__How To Use Me!?__**

* -> Add me to your channel as admin with full previlages

**Bot Commands :**


  * -> `/start` - Start Command
  

  * -> `/batch [channel id]` - To Short Every Links In The Post Of Your Channel
  

* -> `/about` - About The Bot


Pre Requisites 
------------------
* -> __Your Bot Token From [@BotFather](http://www.telegram.dog/BotFather)__

* -> __Your APP ID And API Harsh From [Telegram](http://www.my.telegram.org) or [@UseTGXBot](http://www.telegram.dog/UseTGXBot)__

* -> __Your Telegram ID and ID of Users you want add as Admin__

* -> __Get your MDISK API KEY from https://t.me/VideoToolMoneyTreebot.__

#### PR's Are Very Welcome

## Deploy <br>
You can deploy this bot anywhere.

<p>Deploy To Heroku<P>
<p>

<a href="https://heroku.com/deploy?template=https://github.com/kevinnadar22/MDISK-Convertor">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>
</p>
<br>
Deploy to VPS
<p>
<pre>
git clone https://github.com/kevinnadar22/URL-Shortener-V2
cd URL-Shortener-V2
pip3 install -r requirements.txt
# Change The Vars Of bot/config.py File Accordingly
python3 -m bot
</pre>


## Support   
Contact Our [DEV](https://www.telegram.dog/ask_admin001) For Support/Assistance    
   
Report Bugs, Give Feature Requests There..   
Do Fork And Star The Repository If You Liked It.

## Disclaimer
[![GNU Affero General Public License v3.0](https://www.gnu.org/graphics/agplv3-155x51.png)](https://www.gnu.org/licenses/agpl-3.0.en.html#header)    
Licensed under [GNU AGPL v3.0.](https://github.com/CrazyBotsz/Adv-Auto-Filter-Bot-V2/blob/main/LICENSE)
Selling The Codes To Other People For Money Is *Strictly Prohibited*.


## Credits

 - Thanks To [CrazyBotsz/Adv-Auto-Filter-Bot-V2](https://github.com/CrazyBotsz/Adv-Auto-Filter-Bot-V2) For His Awesome README.md Template
 - [Thanks To Me](https://github.com/Kevinnadar22)
